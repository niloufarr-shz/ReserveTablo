import React from 'react'
import Tablo from '../../components/data/Tablo'
import CallUs from '../../components/callus/page'
function page() {
  return (
    <div className='mt-36'>


<CallUs />
</div>
  )
}

export default page