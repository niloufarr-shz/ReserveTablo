"use client"

import React, { useEffect } from 'react'
import Phoneforme from "../../components/Logins/Phoneforme"
function page() {


  return (
    <section className='max-w-[600px] m-auto flex justify-center items-center'>
    <Phoneforme/>
    </section>
  )
}

export default page