import React from 'react'
import Tablo from '../../components/data/Tablo'


function page() {


  return (
    <div ></div>
  )
}

export default page