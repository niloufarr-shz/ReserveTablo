import React from 'react'

function loading() {
  return (
    <div className='mt-48'>loading . . .</div>
  )
}

export default loading