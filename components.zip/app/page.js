import SelectCity from "../components/MainFile/SelectCity";
import SquareSlider from "../components/MainFile/SquareSlider";
import Mydata from "../components/main/Mydata";
export default function Home() {
  return (
    <>
      <SelectCity />
      <Mydata/>
      <SquareSlider />
    </>
  );
}
